import pandas as pd
import numpy as np
from keras.models import load_model

# Passo 2: Carregar o modelo treinado
modelo = load_model('modelo_treinado.keras')

# Passo 3: Definir as colunas (features)
colunas = ['GRE Score', 'TOEFL Score', 'University Rating', 'SOP', 'LOR', 'CGPA', 'Research']

def solicitar_entrada_manual():
    print("\nDigite os valores do aluno conforme solicitado:")
    entradas = []
    
    for coluna in colunas:
        while True:
            try:
                valor = float(input(f"{coluna}: "))
                
                # Passo 3.1: Validação simples com base nas regras de negócio
                if coluna == 'GRE Score' and not (260 <= valor <= 340):
                    raise ValueError("GRE Score deve estar entre 260 e 340.")
                elif coluna == 'TOEFL Score' and not (0 <= valor <= 120):
                    raise ValueError("TOEFL Score deve estar entre 0 e 120.")
                elif coluna == 'University Rating' and not (1 <= valor <= 5):
                    raise ValueError("University Rating deve estar entre 1 e 5.")
                elif coluna in ['SOP', 'LOR'] and not (1 <= valor <= 5):
                    raise ValueError(f"{coluna} deve estar entre 1 e 5.")
                elif coluna == 'CGPA' and not (0.0 <= valor <= 10.0):
                    raise ValueError("CGPA deve estar entre 0.0 e 10.0.")
                elif coluna == 'Research' and valor not in [0, 1]:
                    raise ValueError("Research deve ser 0 (Não) ou 1 (Sim).")
                
                entradas.append(valor)
                break
            except ValueError as e:
                print(f"Erro: {e}. Tente novamente.")
    
    return np.array(entradas).reshape(1, -1)

# Passo 4: Coletar os dados
entrada_array = solicitar_entrada_manual()

# Passo 5: Realizar a previsão
previsao = modelo.predict(entrada_array)

# Passo 6: Exibir o resultado final
chance = previsao[0][0]
print(f"\nChance de Admissão: {chance * 100:.2f}%")

